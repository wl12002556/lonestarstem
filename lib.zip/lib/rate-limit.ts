import { RateLimiter } from 'limiter'

// Create a rate limiter that allows 5 requests per minute
const limiter = new RateLimiter({
  tokensPerInterval: 5,
  interval: 'minute',
  fireImmediately: true,
})

export const rateLimit = {
  limit: async (key: string) => {
    const result = await limiter.removeTokens(1)
    return { success: result > 0 }
  }
}

