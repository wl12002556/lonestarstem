import Image from 'next/image'

export function Schools() {
  const schools = [
    // Add your school data here
  ]

  return (
    <section className="py-20 bg-white relative overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">
          Our Students Have Been Accepted To
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
          {schools.map((school, index) => (
            <div key={index} className="flex flex-col items-center">
              <div className="relative w-full aspect-[3/2] mb-4">
                <Image
                  src={school.image}
                  alt={`${school.name} campus`}
                  fill
                  className="object-cover rounded-lg shadow-md"
                />
              </div>
              <p className="text-gray-800 font-medium text-center">{school.name}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

