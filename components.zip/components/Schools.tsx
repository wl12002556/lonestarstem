import Image from 'next/image'

export function Schools() {
  const schools = [
    { name: "Harvard", image: "/harvard.jpg" },
    { name: "MIT", image: "/mit.jpg" },
    { name: "Princeton", image: "/princeton.jpg" },
    { name: "Stanford", image: "/stanford.jpg" },
    { name: "UCLA", image: "/ucla.jpg" },
    { name: "Duke", image: "/duke.jpg" },
  ]

  return (
    <section className="">
      <div className="absolute inset-0 z-0">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" className="absolute top-0 left-0 w-full h-full">
          <path fill="#E0F7FA" fillOpacity="0.5" d="M0,96L48,112C96,128,192,160,288,186.7C384,213,480,235,576,224C672,213,768,171,864,149.3C960,128,1056,128,1152,149.3C1248,171,1344,213,1392,234.7L1440,256L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"></path>
        </svg>
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <h2 className="text-3xl font-bold text-center text-cyan-900 mb-12">
          Our Students Have Been Accepted To
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
          {schools.map((school, index) => (
            <div key={index} className="flex flex-col items-center">
              <div className="relative w-full aspect-[3/2] mb-4">
                <Image
                  src={school.image}
                  alt={`${school.name} campus`}
                  fill
                  className="object-cover rounded-lg shadow-md"
                />
              </div>
              <p className="text-cyan-900 font-medium text-center">{school.name}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

