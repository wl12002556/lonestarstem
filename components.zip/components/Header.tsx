import Image from 'next/image'
import Link from 'next/link'

export function Header() {
  return (
    <header className="bg-cyan-500 text-white py-4">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link href="/" className="flex items-center hover:opacity-90 transition-opacity">
          <Image src= "/logo-svg.svg" alt="The Academic Vault Logo" width={350} height={10000} />
          <span className="ml-2 text-2xl font-bold font-fredoka"></span>
        </Link>
        <nav>
          <ul className="flex space-x-6">
            {['Scholarships', 'Extracurriculars', 'Programs'].map((item) => (
              <li key={item}>
                <Link 
                  href={`/${item.toLowerCase()}`} 
                  className="bg-white text-cyan-600 px-4 py-2 rounded-full font-bold hover:bg-cyan-100 transition-colors"
                >
                  {item}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  )
}

