import { useState, useEffect } from 'react'
import Image from 'next/image'
import { Bookmark, Loader2 } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Opportunity } from '@/utils/opportunityStore'
import { AuthModal } from './auth/AuthModal'
import { toast } from 'react-hot-toast'

interface OpportunityCardProps extends Opportunity {
  onView: (opportunity: Opportunity) => void;
}

export function OpportunityCard(props: OpportunityCardProps) {
  const { onView, ...opportunity } = props
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false)
  const [isBookmarked, setIsBookmarked] = useState(false)
  const [isBookmarking, setIsBookmarking] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await fetch('/api/auth/check', { credentials: 'include' });
        setIsAuthenticated(response.ok);
      } catch (error) {
        console.error('Error checking authentication:', error);
      }
    };
    checkAuth();
  }, []);

  const handleBookmarkClick = async () => {
    setIsBookmarking(true);
    try {
      console.log('Attempting to bookmark opportunity:', opportunity.id);
      const response = await fetch('/api/bookmarks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          opportunityId: opportunity.id,
        }),
        credentials: 'include',
      });

      console.log('Bookmark API response status:', response.status);
      const responseData = await response.json();
      console.log('Bookmark API response data:', responseData);

      if (!response.ok) {
        if (response.status === 401) {
          console.log('User is not authenticated. Opening auth modal.');
          setIsAuthModalOpen(true);
          return;
        }
        throw new Error(responseData.message || 'Failed to bookmark opportunity');
      }

      setIsBookmarked(!isBookmarked);
      toast.success(responseData.message || 'Opportunity bookmarked successfully!');
    } catch (error) {
      console.error('Error bookmarking opportunity:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to bookmark opportunity. Please try again.');
    } finally {
      setIsBookmarking(false);
    }
  };

  const handleAuthSuccess = () => {
    setIsAuthenticated(true);
    handleBookmarkClick();
  }

  return (
    <>
      <div className="bg-white rounded-xl border-2 border-cyan-100 p-4 flex items-start gap-4 group hover:border-cyan-600 transition-colors">
        <div className="relative w-16 h-16 flex-shrink-0">
          <Image
            src={opportunity.logo}
            alt={opportunity.organization}
            fill
            className="object-cover rounded-lg"
          />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-lg text-cyan-900 mb-1">{opportunity.title}</h3>
          <p className="text-cyan-600 mb-2">{opportunity.organization}</p>
          <div className="flex flex-wrap gap-2">
            {opportunity.tags.map((tag, index) => (
              <span
                key={index}
                className="px-2 py-1 rounded-full text-sm font-medium bg-cyan-100 text-cyan-600"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <button 
            className={`text-cyan-600 hover:text-cyan-800 ${isBookmarked ? 'text-cyan-800' : ''}`}
            onClick={handleBookmarkClick}
            disabled={isBookmarking || !isAuthenticated}
          >
            {isBookmarking ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Bookmark className={`w-5 h-5 ${isBookmarked ? 'fill-current' : ''}`} />
            )}
          </button>
          <Button
            onClick={() => onView(opportunity)}
            className="px-4 py-1 rounded-full bg-cyan-600 text-white text-sm font-medium hover:bg-cyan-700 transition-colors"
          >
            View
          </Button>
        </div>
      </div>

      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccess={handleAuthSuccess}
      />
    </>
  )
}

