import { useRouter } from 'next/navigation'

export function Features() {
  const router = useRouter()
  const features = [
    {
      title: "Find Scholarships",
      description: "Access thousands of scholarship opportunities to fund your education journey.",
      link: "/scholarships"
    },
    {
      title: "Find Programs",
      description: "Discover enriching educational programs that align with your interests and goals.",
      link: "/programs"
    },
    {
      title: "Find Competitions",
      description: "Explore competitive opportunities to showcase your talents and build your portfolio.",
      link: "/extracurriculars"
    }
  ]

  return (
    <section className="py-20 bg-white relative overflow-hidden min-h-screen flex items-end pb-32">
      <div className="absolute inset-0 z-0">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" className="absolute bottom-0 left-0 w-full h-full">
          <path fill="#FFFFFF" fillOpacity="0.3" d="M0,96L48,112C96,128,192,160,288,186.7C384,213,480,235,576,224C672,213,768,171,864,149.3C960,128,1056,128,1152,149.3C1248,171,1344,213,1392,234.7L1440,256L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
        </svg>
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="flex flex-col items-center text-center">
              <button 
                className="bg-cyan-600 text-white text-lg font-extrabold py-4 px-8 rounded-full hover:bg-cyan-700 transition-colors mb-4"
                onClick={() => router.push(feature.link)}
              >
                {feature.title}
              </button>
              <p className="text-cyan-900 font-semibold">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

