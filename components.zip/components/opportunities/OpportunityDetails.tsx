'use client'

import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { ExternalLink } from 'lucide-react'

interface OpportunityDetailsProps {
  isOpen: boolean
  onClose: () => void
  opportunity: {
    title: string
    organization: string
    logo: string
    location: {
      state: string
      city: string
      type: string
    }
    price: {
      type: string
      amount?: number
    }
    details: string[]
    eligibility: string[]
    description: string
    applyUrl: string
  }
}

export function OpportunityDetails({ isOpen, onClose, opportunity }: OpportunityDetailsProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-start gap-4 mb-6">
          <div className="relative w-16 h-16 flex-shrink-0">
            <Image
              src={opportunity.logo}
              alt={opportunity.organization}
              fill
              className="object-cover rounded-lg"
            />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-cyan-900">{opportunity.title}</h2>
            <p className="text-cyan-600">{opportunity.organization}</p>
          </div>
        </div>

        <div className="space-y-6">
          <section>
            <h3 className="text-lg font-semibold mb-2">Location</h3>
            <div className="flex gap-2">
              <Badge variant="secondary">{opportunity.location.state}</Badge>
              <Badge variant="secondary">{opportunity.location.city}</Badge>
              <Badge variant="secondary">{opportunity.location.type}</Badge>
            </div>
          </section>

          <section>
            <h3 className="text-lg font-semibold mb-2">Price</h3>
            <Badge variant="secondary">{opportunity.price.type}</Badge>
            {opportunity.price.amount && (
              <span className="ml-2 text-cyan-900">${opportunity.price.amount}</span>
            )}
          </section>

          <section>
            <h3 className="text-lg font-semibold mb-2">Details</h3>
            <div className="flex flex-wrap gap-2">
              {opportunity.details.map((detail, index) => (
                <Badge key={index} variant="secondary">{detail}</Badge>
              ))}
            </div>
          </section>

          <section>
            <h3 className="text-lg font-semibold mb-2">Eligibility</h3>
            <div className="flex flex-wrap gap-2">
              {opportunity.eligibility.map((item, index) => (
                <Badge key={index} variant="secondary">{item}</Badge>
              ))}
            </div>
          </section>

          <section>
            <h3 className="text-lg font-semibold mb-2">Description</h3>
            <p className="text-gray-700 whitespace-pre-wrap">{opportunity.description}</p>
          </section>

          <Button
            className="w-full bg-cyan-600 hover:bg-cyan-700"
            onClick={() => window.open(opportunity.applyUrl, '_blank')}
          >
            Apply Here <ExternalLink className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

