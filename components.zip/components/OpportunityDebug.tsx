import { useEffect, useState } from 'react';
import { getOpportunities, loadOpportunities, Opportunity } from '@/utils/opportunityStore';

interface OpportunityDebugProps {
  type: 'scholarships' | 'extracurriculars' | 'programs';
}

export const OpportunityDebug: React.FC<OpportunityDebugProps> = ({ type }) => {
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);

  useEffect(() => {
    const loadData = async () => {
      await loadOpportunities(type);
      setOpportunities(getOpportunities(type));
    };
    loadData();
  }, [type]);

  return (
    <div className="bg-white p-4 rounded-lg shadow-md mt-4">
      <h2 className="text-xl font-bold mb-4">Loaded {type}</h2>
      <p>Total {type}: {opportunities.length}</p>
      <ul className="mt-4 space-y-2">
        {opportunities.slice(0, 5).map((opp, index) => (
          <li key={index} className="border-b pb-2">
            <p><strong>Title:</strong> {opp.title}</p>
            <p><strong>Organization:</strong> {opp.organization}</p>
            <p><strong>Tags:</strong> {opp.tags.join(', ')}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

