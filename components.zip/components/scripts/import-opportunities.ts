import { PrismaClient } from '@prisma/client'
import csv from 'csv-parse'
import fs from 'fs'

const prisma = new PrismaClient()

async function importOpportunities(filePath: string) {
  const opportunities: any[] = []

  fs.createReadStream(filePath)
    .pipe(csv.parse({ columns: true, delimiter: ',' }))
    .on('data', (row) => {
      // Transform CSV row to match Prisma schema
      const opportunity = {
        title: row.title,
        organization: row.organization,
        logo: row.logo,
        description: row.description,
        location: JSON.parse(row.location),
        price: JSON.parse(row.price),
        details: row.details.split(','),
        eligibility: row.eligibility.split(','),
        applyUrl: row.applyUrl,
        type: row.type,
        tags: row.tags.split(','),
      }
      opportunities.push(opportunity)
    })
    .on('end', async () => {
      try {
        // Use Prisma to create opportunities in batches
        await prisma.opportunity.createMany({
          data: opportunities,
          skipDuplicates: true,
        })
        console.log(`Successfully imported ${opportunities.length} opportunities`)
      } catch (error) {
        console.error('Error importing opportunities:', error)
      } finally {
        await prisma.$disconnect()
      }
    })
}

// Example CSV format:
/*
title,organization,logo,description,location,price,details,eligibility,applyUrl,type,tags
"Summer STEM Camp","UNLV","/unlv-logo.png","Description here","{\"state\":\"NV\",\"city\":\"Las Vegas\",\"type\":\"In-Person\"}","{\"type\":\"Paid\",\"amount\":1000}","STEM,University,Program","Domestic Students","https://example.com/apply","program","STEM,Summer,Nevada"
*/

