import React, { useState, useEffect } from 'react';
import Papa from 'papaparse';

const FilterBar = ({ filters = {}, onFilterChange, csvFilePath }) => {
  const [selectedFilters, setSelectedFilters] = useState({});
  const [csvData, setCsvData] = useState([]);
  const [dynamicFilters, setDynamicFilters] = useState(filters);

  // Load CSV data if `csvFilePath` is provided
  useEffect(() => {
    if (csvFilePath) {
      Papa.parse(csvFilePath, {
        download: true,
        header: true,
        complete: (results) => {
          setCsvData(results.data);
          // Transform CSV data into filters (assuming columns represent filter keys and their unique values)
          const generatedFilters = {};
          results.data.forEach((row) => {
            Object.keys(row).forEach((key) => {
              if (!generatedFilters[key]) generatedFilters[key] = new Set();
              generatedFilters[key].add(row[key]);
            });
          });

          // Convert sets to arrays for rendering
          const filterObject = {};
          Object.keys(generatedFilters).forEach((key) => {
            filterObject[key] = Array.from(generatedFilters[key]);
          });
          setDynamicFilters(filterObject);
        },
      });
    }
  }, [csvFilePath]);

  const handleFilterChange = (key, value) => {
    const updatedFilters = {
      ...selectedFilters,
      [key]: value,
    };
    setSelectedFilters(updatedFilters);
    if (onFilterChange) {
      onFilterChange(updatedFilters);
    }
  };

  return (
    <div className="filter-bar bg-purple-100 p-4 rounded-md shadow-md">
      <div className="flex items-center space-x-4">
        <input
          type="text"
          placeholder="Search"
          className="flex-grow p-2 rounded-md border border-purple-300 focus:outline-none focus:ring focus:ring-purple-200"
          onChange={(e) => handleFilterChange('search', e.target.value)}
        />
        <button className="p-2 bg-purple-500 text-white rounded-md hover:bg-purple-600">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-5 w-5"
            viewBox="0 0 20 20"
            fill="currentColor"
          >
            <path
              fillRule="evenodd"
              d="M12.9 14.32a8 8 0 111.414-1.414l4.387 4.386a1 1 0 01-1.414 1.415l-4.387-4.387zM8 14a6 6 0 100-12 6 6 0 000 12z"
              clipRule="evenodd"
            />
          </svg>
        </button>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {dynamicFilters && Object.keys(dynamicFilters).length > 0 ? (
          Object.keys(dynamicFilters).map((key) => (
            <div key={key} className="filter-item">
              <select
                id={key}
                className="rounded-md border-gray-300 shadow-sm focus:ring-purple-500 focus:border-purple-500 sm:text-sm"
                onChange={(e) => handleFilterChange(key, e.target.value)}
                value={selectedFilters[key] || ''}
              >
                <option value="">All {key}</option>
                {dynamicFilters[key].map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>
          ))
        ) : (
          <p>No filters available.</p>
        )}
      </div>
    </div>
  );
};

export default FilterBar;
