'use client'

import { useState, useEffect, useCallback } from 'react'
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

interface FilterOption {
  id: string
  label: string
}

interface FilterCategory {
  id: string
  label: string
  options: FilterOption[]
}

const filterCategories: FilterCategory[] = [
  {
    id: 'cost',
    label: 'Cost',
    options: [
      { id: 'free', label: 'Free' },
      { id: 'paid', label: 'Paid' },
      { id: 'scholarship', label: 'Scholarship Available' },
    ]
  },
  {
    id: 'demographics',
    label: 'Demographics',
    options: [
      { id: 'high-school', label: 'High School Students' },
      { id: 'underserved', label: 'Underserved Communities' },
      { id: 'first-gen', label: 'First Generation' },
    ]
  },
  {
    id: 'location',
    label: 'Location',
    options: [
      { id: 'residential', label: 'Residential' },
      { id: 'virtual', label: 'Virtual' },
      { id: 'hybrid', label: 'Hybrid' },
    ]
  },
]

interface FilterPanelProps {
  onFilterChange: (filters: Record<string, string[]>) => void;
  isOpen: boolean;
}

export function FilterPanel({ onFilterChange, isOpen }: FilterPanelProps) {
  const [selectedFilters, setSelectedFilters] = useState<Record<string, string[]>>({})

  const handleFilterChange = useCallback((categoryId: string, optionId: string, checked: boolean) => {
    setSelectedFilters(prev => {
      const categoryFilters = prev[categoryId] || []
      const updatedFilters = checked
        ? [...categoryFilters, optionId]
        : categoryFilters.filter(id => id !== optionId)

      const newFilters = {
        ...prev,
        [categoryId]: updatedFilters
      }

      return newFilters
    })
  }, [])

  useEffect(() => {
    onFilterChange(selectedFilters)
  }, [selectedFilters, onFilterChange])

  if (!isOpen) return null;

  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <Accordion type="multiple" className="w-full">
        {filterCategories.map(category => (
          <AccordionItem key={category.id} value={category.id}>
            <AccordionTrigger className="text-lg font-semibold">
              {category.label}
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2">
                {category.options.map(option => (
                  <div key={option.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`${category.id}-${option.id}`}
                      checked={selectedFilters[category.id]?.includes(option.id)}
                      onCheckedChange={(checked) => 
                        handleFilterChange(category.id, option.id, checked as boolean)
                      }
                    />
                    <Label htmlFor={`${category.id}-${option.id}`}>
                      {option.label}
                    </Label>
                  </div>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  )
}

