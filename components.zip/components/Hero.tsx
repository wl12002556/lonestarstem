export function Hero() {
  return (
    <section className="bg-cyan-100 text-white py-20 text-center relative overflow-hidden min-h-screen flex items-center">
      <div className="absolute inset-0 z-0">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" className="absolute top-0 left-0 w-full h-full">
        </svg>
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-4 leading-tight">
          <span className="block text-cyan-600">Lessons and Activities</span>
          <span className="block text-cyan-600">In STEM</span>
        </h1>
        <p className="text-xl md:text-2xl font-bold max-w-4xl mx-auto mb-12 text-cyan-900">
          Lone Star Stem Alliance is a nonprofit that offers free lessons and activities in STEM for students in the North Texas area to allow for students of all backgrounds to have access to STEM education.
        </p>
      </div>
    </section>
  )
}

