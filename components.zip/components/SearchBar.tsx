import { Search, Filter } from 'lucide-react'
import { Button } from "@/components/ui/button"

interface SearchBarProps {
  onFilterClick: () => void;
}

export function SearchBar({ onFilterClick }: SearchBarProps) {
  return (
    <div className="flex gap-2 max-w-4xl mx-auto mb-12">
      <div className="flex-1 relative">
        <input
          type="text"
          placeholder="Search..."
          className="w-full px-4 py-3 rounded-xl border-2 border-cyan-200 focus:border-cyan-600 focus:outline-none text-lg"
        />
        <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-cyan-600" />
      </div>
      <Button
        variant="outline"
        className="p-3 rounded-xl border-2 border-cyan-200 hover:border-cyan-600 transition-colors"
        onClick={onFilterClick}
      >
        <Filter className="text-cyan-600" />
      </Button>
    </div>
  )
}

