export function WhyChooseUs() {
  const reasons = [
    {
      title: "Free",
      description: "All our services are completely free of charge, making college prep accessible to everyone."
    },
    {
      title: "Simple",
      description: "Our easy-to-use platform simplifies the search process for scholarships, competitions, and extracurriculars."
    },
    {
      title: "Support for Underserved Students",
      description: "We're committed to supporting underserved students, providing equal opportunities for all."
    }
  ]

  return (
    <section className="py-20 bg-cyan-100 relative overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <h2 className="text-4xl md:text-5xl font-extrabold text-cyan-600 mb-12 text-center">Why Choose Us</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reasons.map((reason, index) => (
            <div key={index} className="bg-white p-8 rounded-lg shadow-lg text-center">
              <h3 className="text-2xl font-extrabold text-cyan-600 mb-4">{reason.title}</h3>
              <p className="text-gray-700 font-medium">{reason.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

