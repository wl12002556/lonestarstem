'use client'

import { useEffect, useState, useCallback } from 'react'
import { Header } from '@/components/Header'
import { SearchBar } from '@/components/SearchBar'
import { OpportunityCard } from '@/components/OpportunityCard'
import { OpportunityDetails } from '@/components/OpportunityDetails'
import { FilterPanel } from '@/components/filter/FilterPanel'
import { OpportunityDebug } from '@/components/OpportunityDebug'
import { getOpportunities, filterOpportunities, loadOpportunities, type Opportunity } from '@/utils/opportunityStore'

export default function ScholarshipsPage() {
  const [opportunities, setOpportunities] = useState<Opportunity[]>([])
  const [filteredOpportunities, setFilteredOpportunities] = useState<Opportunity[]>([])
  const [selectedFilters, setSelectedFilters] = useState<Record<string, string[]>>({})
  const [isFilterOpen, setIsFilterOpen] = useState(false)
  const [selectedOpportunity, setSelectedOpportunity] = useState<Opportunity | null>(null)

  useEffect(() => {
    const loadData = async () => {
      await loadOpportunities('scholarships')
      const scholarships = getOpportunities('scholarships')
      setOpportunities(scholarships)
      setFilteredOpportunities(scholarships)
    }
    loadData()
  }, [])

  useEffect(() => {
    setFilteredOpportunities(filterOpportunities(opportunities, selectedFilters))
  }, [opportunities, selectedFilters])

  const handleFilterChange = useCallback((filters: Record<string, string[]>) => {
    setSelectedFilters(filters)
  }, [])

  const toggleFilter = () => {
    setIsFilterOpen(!isFilterOpen)
  }

  const handleViewOpportunity = (opportunity: Opportunity) => {
    setSelectedOpportunity(opportunity)
  }

  const handleCloseOpportunityDetails = () => {
    setSelectedOpportunity(null)
  }

  return (
    <div className="min-h-screen bg-cyan-50">
      <Header />
      <main className="container mx-auto px-4 py-12">
        <h1 className="text-5xl font-bold text-cyan-900 mb-8">
          Discover your <span className="text-cyan-600">Scholarship</span>
          <div className="h-1 w-32 bg-cyan-600 mt-2"></div>
        </h1>
        <SearchBar onFilterClick={toggleFilter} />
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <aside className="md:col-span-1">
            <FilterPanel onFilterChange={handleFilterChange} isOpen={isFilterOpen} />
            <OpportunityDebug type="scholarships" />
          </aside>
          <div className="md:col-span-3">
            <div className="space-y-4">
              {filteredOpportunities.map((scholarship, index) => (
                <OpportunityCard key={index} {...scholarship} onView={handleViewOpportunity} />
              ))}
            </div>
          </div>
        </div>
      </main>
      <OpportunityDetails
        isOpen={!!selectedOpportunity}
        onClose={handleCloseOpportunityDetails}
        opportunity={selectedOpportunity}
      />
    </div>
  )
}

