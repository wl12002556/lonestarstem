'use client'

import { useEffect } from 'react'
import { Header } from '../components/Header'
import { Hero } from '../components/Hero'
import { Features } from '../components/Features'
import { WhyChooseUs } from '../components/WhyChooseUs'

export default function Home() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('opacity-100')
            entry.target.classList.remove('opacity-0')
          }
        })
      },
      { threshold: 0.1 }
    )

    document.querySelectorAll('.section-transition').forEach((section) => {
      section.classList.add('opacity-0')
      observer.observe(section)
    })

    return () => observer.disconnect()
  }, [])

  return (
    <div className="min-h-screen bg-white font-fredoka">
      <Header />
      <main>
        <div className="section-transition">
          <Hero />
        </div>
        <div className="section-transition">
          <Features />
        </div>
        <div className="section-transition">
          <WhyChooseUs />
        </div>
      </main>
    </div>
  )
}

