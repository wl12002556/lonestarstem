import { Fredoka } from 'next/font/google'
import './globals.css'

const fredoka = Fredoka({ 
  subsets: ['latin'],
  variable: '--font-fredoka',
  display: 'swap',
})

export const metadata = {
  title: 'The Academic Vault',
  description: 'The Best Place to Look for College Prep',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${fredoka.variable} font-sans`}>
      <body>{children}</body>
    </html>
  )
}

