import { NextResponse } from 'next/server'
import { z } from 'zod'
import { PrismaClient } from '@prisma/client'
import { verifyToken } from '@/lib/auth'

const prisma = new PrismaClient()

const bookmarkSchema = z.object({
  opportunityId: z.string(),
})

export async function POST(req: Request) {
  console.log('Bookmark API route called');

  try {
    const token = req.cookies.get('authToken')?.value;
    console.log('Auth token:', token ? 'Present' : 'Missing');

    if (!token) {
      console.log('No auth token found');
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
    }

    let decoded;
    try {
      decoded = await verifyToken(token);
      console.log('Token verified successfully');
    } catch (error) {
      console.error('Token verification failed:', error);
      return NextResponse.json({ message: 'Invalid token' }, { status: 401 });
    }

    const body = await req.json();
    console.log('Request body:', body);

    const { opportunityId } = bookmarkSchema.parse(body);

    // Check if the bookmark already exists
    const existingBookmark = await prisma.bookmark.findFirst({
      where: {
        userId: decoded.userId,
        opportunityId: opportunityId,
      },
    });

    if (existingBookmark) {
      console.log('Bookmark already exists, removing it');
      await prisma.bookmark.delete({
        where: { id: existingBookmark.id },
      });
      return NextResponse.json({ message: 'Bookmark removed successfully', isBookmarked: false });
    } else {
      console.log('Creating new bookmark');
      await prisma.bookmark.create({
        data: {
          userId: decoded.userId,
          opportunityId: opportunityId,
        },
      });
      return NextResponse.json({ message: 'Bookmark added successfully', isBookmarked: true });
    }
  } catch (error) {
    console.error('Error in bookmark API:', error);
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: 'Invalid input', errors: error.errors }, { status: 400 });
    }
    return NextResponse.json({ message: 'Error bookmarking opportunity' }, { status: 500 });
  }
}

