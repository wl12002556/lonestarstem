export async function parseCSV(file: File): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const lines = text.split('\n');
      const headers = lines[0].split(',').map(header => header.trim());
      
      const results = lines.slice(1).map(line => {
        const values = line.split(',').map(value => value.trim());
        return headers.reduce((obj: any, header, index) => {
          // Parse nested JSON objects
          try {
            obj[header] = JSON.parse(values[index]);
          } catch {
            obj[header] = values[index];
          }
          return obj;
        }, {});
      });

      resolve(results);
    };
    reader.onerror = reject;
    reader.readAsText(file);
  });
}

