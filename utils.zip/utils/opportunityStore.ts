import Papa from 'papaparse';

export interface Opportunity {
  id: string;
  title: string;
  organization: string;
  logo: string;
  location: {
    state: string;
    city: string;
    type: string;
  };
  price: {
    type: string;
    amount?: number;
  };
  details: string[];
  eligibility: string[];
  description: string;
  applyUrl: string;
  type: 'scholarship' | 'program' | 'extracurricular';
  tags: string[];
}

const opportunities: Record<string, Opportunity[]> = {
  scholarships: [],
  extracurriculars: [],
  programs: [],
};

export async function loadOpportunities(type: 'scholarships' | 'extracurriculars' | 'programs') {
  try {
    const response = await fetch(`/${type}.csv`);
    const csvData = await response.text();
    
    const results = Papa.parse(csvData, { header: true, dynamicTyping: true });
    
    opportunities[type] = results.data.map((row: any) => ({
      ...row,
      location: JSON.parse(row.location),
      price: JSON.parse(row.price),
      details: JSON.parse(row.details),
      eligibility: JSON.parse(row.eligibility),
      tags: row.tags.split(',').map((tag: string) => tag.trim())
    }));

    console.log(`${type} loaded:`, opportunities[type].length);
  } catch (error) {
    console.error(`Error loading ${type}:`, error);
  }
}

export function getOpportunities(type: 'scholarships' | 'extracurriculars' | 'programs'): Opportunity[] {
  return opportunities[type];
}

export function filterOpportunities(
  opportunities: Opportunity[],
  filters: Record<string, string[]>
): Opportunity[] {
  return opportunities.filter(opportunity => {
    return Object.entries(filters).every(([category, selectedOptions]) => {
      if (selectedOptions.length === 0) return true;

      switch (category) {
        case 'cost':
          return selectedOptions.includes(opportunity.price.type.toLowerCase());
        case 'location':
          return selectedOptions.includes(opportunity.location.type.toLowerCase());
        case 'type':
          return selectedOptions.includes(opportunity.type);
        case 'demographics':
          return selectedOptions.some(option => opportunity.eligibility.includes(option));
        default:
          return selectedOptions.some(option => opportunity.tags.includes(option));
      }
    });
  });
}

