import { NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'
import { z } from 'zod'
import { PrismaClient } from '@prisma/client'
import { rateLimit } from '@/lib/rate-limit'

const prisma = new PrismaClient()
const JWT_SECRET = process.env.JWT_SECRET!

const bookmarkSchema = z.object({
  opportunityId: z.string(),
})

export async function POST(req: Request) {
  try {
    // Rate limiting
    const ip = req.headers.get('x-forwarded-for') || 'unknown'
    const { success } = await rateLimit.limit(ip)
    if (!success) {
      return NextResponse.json({ message: 'Too many requests' }, { status: 429 })
    }

    const token = req.cookies.get('authToken')?.value
    
    if (!token) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string }
    const { opportunityId } = bookmarkSchema.parse(await req.json())

    // Store bookmark in database
    await prisma.bookmark.create({
      data: {
        userId: decoded.userId,
        opportunityId,
      },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: 'Invalid input', errors: error.errors }, { status: 400 })
    }
    console.error('Bookmark error:', error)
    return NextResponse.json({ message: 'Error bookmarking opportunity' }, { status: 500 })
  }
}

