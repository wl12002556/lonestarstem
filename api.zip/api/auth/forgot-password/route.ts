import { NextResponse } from 'next/server'
import { z } from 'zod'
import { PrismaClient } from '@prisma/client'
import { sendPasswordResetEmail } from '@/lib/email'
import { rateLimit } from '@/lib/rate-limit'

const prisma = new PrismaClient()

const forgotPasswordSchema = z.object({
  email: z.string().email(),
})

export async function POST(req: Request) {
  try {
    // Rate limiting
    const ip = req.headers.get('x-forwarded-for') || 'unknown'
    const { success } = await rateLimit.limit(ip)
    if (!success) {
      return NextResponse.json({ message: 'Too many requests' }, { status: 429 })
    }

    const body = await req.json()
    const { email } = forgotPasswordSchema.parse(body)

    const user = await prisma.user.findUnique({ where: { email } })
    if (user) {
      const resetToken = crypto.randomBytes(32).toString('hex')
      const resetTokenExpiry = new Date(Date.now() + 3600000) // 1 hour from now

      await prisma.user.update({
        where: { id: user.id },
        data: { resetToken, resetTokenExpiry },
      })

      await sendPasswordResetEmail(email, resetToken)
    }

    // Always return a success message to prevent email enumeration
    return NextResponse.json({ message: 'If an account with that email exists, a password reset link has been sent.' })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: 'Invalid input', errors: error.errors }, { status: 400 })
    }
    console.error('Forgot password error:', error)
    return NextResponse.json({ message: 'Error processing request' }, { status: 500 })
  }
}

